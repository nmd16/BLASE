# DP Functions 

initialize_DP <-function(Bhat1,Bhat2,prior.alpha,prior.Hstar,p){
  alpha         = prior.alpha
  Hstar         = prior.Hstar 
  
  
  pi.step       = stick_breaking(Hstar,alpha)
  
  stacked       = rbind( Bhat1,Bhat2 )
  #if( is.list(stacked)=="TRUE"){  stacked       = rbind( stacked[[1]], stacked[[2]]) }
  N             = nrow(stacked)
  
  phi <- c() # Initialize an empty list
  for( h in 1:Hstar){
    holder <- c() #For each latent class, we will have a list of vectors. Each vector represents the
    # probabilities of seeing each field entry for each variable, given the latent class.
    for( j in 1:p){
      holder[[j]] <- data.frame(table(stacked[,j])/N)$Freq
    }
    phi[[h]] = holder
  }
  
  newlist <- list( "alpha" = alpha, "pi.step"= pi.step,"phi"= phi)
  
  return(newlist)
}

stick_breaking <-function(Hstar,alpha){
  ##Draw our k betas from a beta(1,alpha) distribution
  first = Hstar-1
  betas = c( rbeta( first,1,alpha) , 1)
  #How long is the stick? 
  whats_left=c(1,cumprod(1-betas))[1:Hstar]
  #We now need to actually get our vector of weights
  #The weights are calculated by multiplying the beta by the remaining length of the stick 
  weights=whats_left*betas
  return(weights)  
}

run_dpmpm_step <-function( Bhat , dpmpm , Hstar, HstarM1, J, hvec,realmin,N,a.alpha,b.alpha,a.dirichlet,d){
  
  
  phi     = dpmpm$phi
  pi.step = dpmpm$pi.step
  alpha   = dpmpm$alpha
  
  #Update Z 
  z <- c()
  for( i in 1:N){ 
    holder <- holder.step(Bhat[i,],phi,Hstar,J)
    num     = pi.step * holder
    probs.z = num/sum(num)
    zi      = sample(1:Hstar,1,replace=T,prob = probs.z)
    z       = c(z, zi)
  }
  
  # Update V 
  nvec         <- create_nvec(z,Hstar)
  V = c()
  for( h in 1:HstarM1){
    V = c( V, update.Vh(h,nvec,alpha, Hstar))
  }
  V = c(V,1)
  
  
  #Update pi
  #How long is the stick? 
  whats_left  = c(1,cumprod(1-V))[1:Hstar]
  #We now need to actually get our vector of weights
  #The weights are calculated by multiplying the beta by the remaining length of the stick 
  pi.step     = whats_left*V
  pi.step     = ifelse(pi.step > 0, pi.step, realmin) #Correction 
  
  # phi 
  phi <-c()
  for( h in 1:Hstar){
    holder <- c() #For each latent class
    for( j in 1:J ){
      avec        = create_avec(z,Bhat,d,j,h,a.dirichlet)
      holder[[j]] <- c(rdirichlet(1,avec))
      #holder[[j]] <-ifelse( holder[[j]] > 0 , holder[[j]], inits.pm$realmin)
    }
    phi[[h]] = holder 
  }
  
  # Update alpha
  alpha = rgamma(1, shape = (a.alpha + Hstar -1), 
                 rate = (b.alpha - log( pi.step[Hstar] ) ) )
  alpha = ifelse( alpha > 0 , alpha, realmin)  
  
  newlist      <-list( "pi.step" = pi.step , "alpha" = alpha , "phi" = phi, "z"=z )
  
  return(newlist)
  
}

holder.step <-function(B.i, phi,Hstar,J){
  holder <- c()
  for( h in 1:Hstar){
    holder = c( holder, prod.part(J,h,B.i,phi))
  }
  return(holder)
}

create_nvec<-function(z,Hstar){
  nvec         = matrix(0,ncol=Hstar,nrow=1) #Bins for the latent classes 
  table.step   = data.frame(table(z))
  places       = as.numeric( levels(table.step$z) )
  nvec[,places]= table.step$Freq 
  return(nvec)
}

create_avec<-function(z,Bhat,d,j,h,a.dirichlet){
  # For the simulated data, look at the observations in the first latent class, and the 2nd blocking variable
  # What is the spread of the data? How many observations in each of the fields?  
  avec         = matrix(0,nrow=1,ncol=d[j]) #Bins for the fields
  if( sum(z ==h) > 0) { 
    table.step   = table( Bhat[which(z ==h),j] ) 
    table.step   = data.frame(table.step)
    level.fill   = table.step$Var1
    avec[,as.numeric(levels(level.fill))]= table.step$Freq
    # From the prior, we add a.dirichlet[[j]][ d[j] ]
    avec = avec + a.dirichlet
  }  else {  avec = avec + a.dirichlet } 
  return(avec)
}

update.Vh <-function(h,nvec,alpha,Hstar){
  a.upd  = 1 + nvec[h]
  b.up   = alpha + sum(nvec[(h+1):Hstar])
  Vh.up  = rbeta(1,a.upd,b.up)
  return(Vh.up)
}

rigamma<-function (n, alpha, beta){
  if (alpha > 0 & beta > 0) 
    1/rgamma(n = n, alpha, beta)
  else stop("rigamma: invalid parameters\n")
}

prod.part <-function(J,h,B.i,phi.term){
  holder1 = 1
  for( j in 1:J ){
    holder.part = phi.term[[h]][[j]][B.i[j]]
    holder1 = holder1 %*% holder.part
  }
  return( holder1 )
}

rdirichlet<-function (n, alpha){
  l <- length(alpha)
  x <- matrix(rgamma(l * n, alpha), ncol = l, byrow = TRUE)
  sm <- x %*% rep(1, l)
  return(x/as.vector(sm))
}