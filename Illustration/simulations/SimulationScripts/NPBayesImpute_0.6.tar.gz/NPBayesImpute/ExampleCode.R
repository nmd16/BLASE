# Test Script for Quanli

load("DataSpace.RData")

require(NPBayesImpute)
for( j in 1:J){
  if(class(B[,j]) != "factor"){
    B[,j] = as.factor(B[,j])
  }
}


model <-CreateModel(B, NULL, Hstar, 0, 0.25,0.25)
model$Run(10,1000,2)
dpmpm <-model$snapshot

UpdateX(model,B)
model$Run(0,2,1)


# Change the data 

for( i in 1:its){
  # Choose a few rows
  changed.rows = sample(1:N,500,replace = F)
  # Choose the columns to change 
  changed.columns = sample(c(1,3:5),500,replace = T)
  # Store the Changes
  change.holder = changed.rows
  
  # Choose a new value for those rows for Column 1 
  J1subset = subset(changed.rows,changed.columns==1)
  n.J1 = length(J1subset)
  sampled.values.1 = sample(levels(B[,1]),n.J1,replace=T)
  changed.holder[J1subset] = sampled.values.1
  # Choose a new value for those rows for Column 3 
  J3subset = subset(changed.rows,changed.columns==3)
  n.J3 = length(J3subset)
  sampled.values.3 = sample(levels(B[,3]),n.J3,replace=T)
  changed.holder[J3subset] = sampled.values.3
  # Choose a new value for those rows for Column 4 
  J4subset = subset(changed.rows,changed.columns==4)
  n.J4 = length(J4subset)
  sampled.values.4 = sample(levels(B[,4]),n.J4,replace=T)
  changed.holder[J4subset] = sampled.values.4  
  # Choose a new value for those rows for Column 5 
  J5subset = subset(changed.rows,changed.columns==5)
  n.J5 = length(J5subset)
  sampled.values.5 = sample(levels(B[,5]),n.J5,replace=T)
  changed.holder[J5subset] = sampled.values.5
  
  B[changed.rows,changed.columns] = changed.holder 
  
  
  # Here, I need the DP to update to use this new B 
  # The code below WILL NOT work right now, but that's what I need 
  model$Run(0,2,1)
  dpmpm <-model$snapshot
  
}
